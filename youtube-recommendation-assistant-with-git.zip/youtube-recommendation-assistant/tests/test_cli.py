"""Repeatable CLI checks for the supplied, unchanged Python program.

Run from the repository root with:
    python -m unittest discover -s tests -v

The expected-failure test records an existing Unicode numeric-input bug.
"""

from pathlib import Path
import subprocess
import sys
import unittest


PROGRAM = (
    Path(__file__).resolve().parents[1]
    / "src"
    / "youtube_recommendation_assistant.py"
)


class RecommendationCliTests(unittest.TestCase):
    def run_cli(self, *answers):
        result = subprocess.run(
            [sys.executable, "-X", "utf8", str(PROGRAM)],
            input="\n".join(answers) + "\n",
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=10,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def test_startup_catalog_and_exit(self):
        output = self.run_cli("7")
        self.assertIn("Videos loaded: 30", output)
        self.assertIn("Thank you for using the YouTube Recommendation Assistant.", output)

    def test_invalid_menu_inputs_are_retried(self):
        output = self.run_cli("abc", "0", "8", "7")
        self.assertEqual(output.count("Invalid input. Enter a number from 1 to 7."), 3)
        self.assertIn("Thank you for using", output)

    def test_category_ignores_case_and_surrounding_spaces(self):
        output = self.run_cli("1", "  tEcH  ", "2", "7")
        for title in (
            "Building a Startup in 2026",
            "How AI Is Changing Everyday Apps",
            "Coding a Simple Game in a Weekend",
            "Watch this BEFORE you buy a Camera!",
        ):
            self.assertIn(title, output)
        self.assertNotIn("History of the Ottoman Empire", output)
        self.assertIn("No video added.", output)

    def test_unknown_category_and_mood_return_to_menu(self):
        output = self.run_cli("1", "unknown", "2", "unknown", "7")
        self.assertIn("No videos found in that category.", output)
        self.assertIn("No videos found for that mood.", output)
        self.assertIn("Thank you for using", output)

    def test_mood_results_are_sorted_by_popularity(self):
        output = self.run_cli("2", "funny", "2", "7")
        titles = (
            "Funniest Cat Fails Compilation",
            "Try Not to Laugh Challenge",
            "Awkward First Date Sketches",
            "Stand-Up Comedy Highlights",
        )
        positions = [output.index(title) for title in titles]
        self.assertEqual(positions, sorted(positions))
        self.assertNotIn("Meditation for Beginners", output)

    def test_time_filter_empty_result_and_inclusive_limit(self):
        output = self.run_cli("3", "5", "3", "10", "2", "7")
        self.assertIn("No videos fit that time limit. Try a higher number.", output)
        titles = (
            "Funniest Cat Fails Compilation",
            "Awkward First Date Sketches",
            "10-Minute Full Body Workout",
            "Meditation for Beginners",
        )
        positions = [output.index(title) for title in titles]
        self.assertEqual(positions, sorted(positions))
        self.assertNotIn("Try Not to Laugh Challenge", output)

    def test_time_filter_rejects_out_of_range_input(self):
        output = self.run_cli("3", "abc", "4", "121", "10", "2", "7")
        self.assertEqual(output.count("Invalid input. Enter a number from 5 to 120."), 3)
        self.assertIn("10-Minute Full Body Workout", output)

    def test_watch_later_prevents_duplicates_and_totals_duration(self):
        output = self.run_cli("1", "Tech", "1", "1", "1", "Tech", "1", "1", "4", "7")
        self.assertIn('"Building a Startup in 2026" added to Watch Later.', output)
        self.assertIn('"Building a Startup in 2026" is already in Watch Later.', output)
        self.assertIn("Total: 1 video(s), 18 minutes of watch time.", output)

    def test_clearing_can_be_cancelled_then_confirmed(self):
        output = self.run_cli("1", "Tech", "1", "1", "5", "2", "4", "5", "1", "4", "5", "7")
        self.assertIn("Cancelled.", output)
        self.assertIn("Total: 1 video(s), 18 minutes of watch time.", output)
        self.assertIn("Watch Later list cleared.", output)
        self.assertIn("Your Watch Later list is empty.", output)
        self.assertIn("The list is already empty.", output)

    def test_watch_later_is_empty_in_a_new_session(self):
        first_session = self.run_cli("1", "Tech", "1", "1", "4", "7")
        self.assertIn("Total: 1 video(s), 18 minutes of watch time.", first_session)
        second_session = self.run_cli("4", "7")
        self.assertIn("Your Watch Later list is empty.", second_session)

    @unittest.expectedFailure
    def test_known_unicode_numeric_input_should_be_rejected_without_crashing(self):
        # Superscript two passes str.isdigit(), but int() raises ValueError.
        # Preserve this known failure while keeping the supplied source unchanged.
        output = self.run_cli("\u00b2", "7")
        self.assertIn("Invalid input. Enter a number from 1 to 7.", output)


if __name__ == "__main__":
    unittest.main(verbosity=2)
