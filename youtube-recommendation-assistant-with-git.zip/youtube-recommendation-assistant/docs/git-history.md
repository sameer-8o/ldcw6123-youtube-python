# Git development evidence

## What this history records

Git tracking began with an existing Python program supplied as `python code.txt`. The first commit imports that complete program under a `.py` filename. It is followed by actual documentation and verification work performed during repository preparation.

The application source is preserved unchanged. No earlier source versions, original development commits or dates were supplied for this Python program. This repository therefore cannot prove that commits were made regularly during its original design and implementation. No such history has been reconstructed or backdated.

## Recorded work

- **Baseline:** import the supplied Python assistant and add Python ignore rules.
- **Documentation:** describe how to run the program, its inputs and outputs, its current logic, and the scope of the available history.
- **Verification:** add and execute reproducible CLI checks and record their results.

Each commit message identifies the work actually included in that commit. Git uses the existing local author configuration and the current system timestamp.

## Export the real log

From the repository root:

```bash
git log --oneline --graph
git log --format=fuller --stat
```

Copy the first command's output into the report or capture the terminal displaying it. The second command provides dates and the files changed in each commit. A branch history can be linear: a single vertical graph line is normal.

The assignment uses `--online`; Git's option is `--oneline`.

## Continue development

For each future change, complete the work, check it, and commit a clear description. For example, if a real future change adds persistent Watch Later storage, commit that change only after implementing and checking it. Do not add commits claiming stages that did not occur.

## GitHub

- Repository: https://github.com/sameer-8o/ldcw6123-youtube-python
- GitHub upload history: https://github.com/sameer-8o/ldcw6123-youtube-python/commits/main/

The browser is signed in to GitHub, but command-line Git authentication is unavailable. The source and evidence are therefore uploaded through the website. GitHub's commit list records these uploads; it is separate from the local development history exported with `git log`.

The uploaded ZIP includes the local `.git` directory, and the uploaded Git bundle preserves the local commits and their identifiers. The text logs refer to that local history. Clone the bundle to inspect it with Git:

```bash
git clone youtube-recommendation-assistant.bundle restored-project
git -C restored-project log --oneline --graph
```

The repository is private; a lecturer or group member needs access before they can open these links.
