# Inputs, outputs and implemented logic

This document describes the existing supplied program. It was prepared after the program was imported into Git; it is not a record of an earlier planning session.

## Inputs and outputs

| Operation | Input | Output |
| --- | --- | --- |
| Main menu | Integer 1-7 | Selected feature or exit message |
| Category search | Tech, Music, Fitness, Education, Comedy, Gaming or Vlog | Matching video rows, or a no-match message |
| Mood search | Relaxing, Exciting, Informative or Funny | Matching videos, descending by sample views |
| Time filter | Integer 5-120 | Videos within the duration limit, shortest first |
| Save a result | Yes/no, then displayed video number | Saved confirmation or duplicate message |
| View Watch Later | Menu option 4 | Saved video rows, count and total minutes, or an empty message |
| Clear Watch Later | 1 to clear, 2 to cancel | Cleared, cancelled or already-empty message |
| Innovation explanation | Menu option 6 | Short text connecting YouTube to the innovation topic |

Each video has a title, category, mood, duration in minutes, sample view count in millions, channel and description.

## Implemented control flow

1. Load the 30 sample videos and create an empty Watch Later list.
2. Show the menu and obtain a number in the allowed range.
3. Dispatch to a feature using `if`/`elif` branches.
4. For searches, filter the catalogue with list comprehensions. Sort mood matches by views and duration matches by minutes.
5. Offer to save one of the displayed results. Check for an existing title before adding it.
6. Return to the menu until option 7 is selected.

`read_integer()` repeats ordinary invalid input prompts. Text inputs use `strip().lower()`. The data model is a `Video` dataclass and Watch Later is a Python list.
