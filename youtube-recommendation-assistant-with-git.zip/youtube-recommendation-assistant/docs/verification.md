# Verification results

Executed: 2026-09-27T21:11:53+08:00

Runtime: Python 3.12.14 on Windows.

Command, run from the repository root:

```bash
python -m unittest discover -s tests -v
```

## Result

11 tests executed: **10 passed and 1 expected failure**. The expected failure records a known defect; it is not a passing application scenario.

The passing scenarios cover startup and exit, invalid menu inputs, category matching, no-match searches, mood sorting, time filtering and boundaries, duplicate prevention, saved duration totals, clear/cancel behavior, and session-only storage.

## Known defect retained in the supplied source

Entering superscript two (`²`) at a numeric prompt crashes the program with `ValueError`. Python's `str.isdigit()` accepts that character, but `int()` cannot convert it. The test is marked `expectedFailure` to document the defect while preserving the user's source. The current work packages and documents the supplied code; it does not fix that code.

EOF and keyboard interruption handling and table alignment were not covered by these automated tests. The innovation explanation was not fact-checked by these tests.

## Source verification

The `.py` file is byte-for-byte identical to the supplied `python code.txt`.

SHA-256: `ce48017b1c4b0e648a9791f93d4ebde18dea430be75f426cc195a323473c1250`

## Captured test output

```text
test_category_ignores_case_and_surrounding_spaces (test_cli.RecommendationCliTests.test_category_ignores_case_and_surrounding_spaces) ... ok
test_clearing_can_be_cancelled_then_confirmed (test_cli.RecommendationCliTests.test_clearing_can_be_cancelled_then_confirmed) ... ok
test_invalid_menu_inputs_are_retried (test_cli.RecommendationCliTests.test_invalid_menu_inputs_are_retried) ... ok
test_known_unicode_numeric_input_should_be_rejected_without_crashing (test_cli.RecommendationCliTests.test_known_unicode_numeric_input_should_be_rejected_without_crashing) ... expected failure
test_mood_results_are_sorted_by_popularity (test_cli.RecommendationCliTests.test_mood_results_are_sorted_by_popularity) ... ok
test_startup_catalog_and_exit (test_cli.RecommendationCliTests.test_startup_catalog_and_exit) ... ok
test_time_filter_empty_result_and_inclusive_limit (test_cli.RecommendationCliTests.test_time_filter_empty_result_and_inclusive_limit) ... ok
test_time_filter_rejects_out_of_range_input (test_cli.RecommendationCliTests.test_time_filter_rejects_out_of_range_input) ... ok
test_unknown_category_and_mood_return_to_menu (test_cli.RecommendationCliTests.test_unknown_category_and_mood_return_to_menu) ... ok
test_watch_later_is_empty_in_a_new_session (test_cli.RecommendationCliTests.test_watch_later_is_empty_in_a_new_session) ... ok
test_watch_later_prevents_duplicates_and_totals_duration (test_cli.RecommendationCliTests.test_watch_later_prevents_duplicates_and_totals_duration) ... ok

----------------------------------------------------------------------
Ran 11 tests in 1.134s

OK (expected failures=1)
```
