# YouTube Video Recommendation Assistant

A terminal-based Python project for **LDCW6123 - Fundamentals of Digital Competence for Programmer**. It demonstrates a small recommendation system using 30 sample videos and connects the program to the group's YouTube innovation topic.

Repository: https://github.com/sameer-8o/ldcw6123-youtube-python

## Run

Use Python 3.7 or later. Only Python's standard library is required; no packages, API keys or network connection are needed.

From this repository's root folder:

```bash
python src/youtube_recommendation_assistant.py
```

On Windows, `py` may be used instead of `python` when the Python launcher is installed.

## Features

1. Recommend videos by category.
2. Recommend videos by mood, ordered by sample view count.
3. Filter videos by available time (5-120 minutes), shortest first.
4. View a Watch Later list and its total duration.
5. Clear the Watch Later list after confirmation.
6. Display a short explanation of YouTube's innovation.
7. Exit.

Saving a video twice is prevented by checking its title. Input matching for categories and moods ignores letter case and surrounding spaces.

## Project files

```text
src/youtube_recommendation_assistant.py   Supplied program, preserved unchanged
docs/inputs-and-outputs.md               Inputs, outputs and implemented logic
docs/git-history.md                      Scope of the recorded Git history
tests/test_cli.py                        Repeatable command-line checks
docs/verification.md                     Results of the checks
```

## Check the program

```bash
python -m unittest discover -s tests -v
```

See [verification results](docs/verification.md) for the tested scenarios and remaining limitations.

## Data and limitations

- The catalogue and view counts are fixed sample data. This program does not query YouTube, play videos or use a machine-learning model.
- Watch Later is stored in memory and resets when the program closes.
- Category and mood searches require one of the displayed words; partial matches are not supported.
- Long video titles can run into adjacent display columns.
- The program retries ordinary invalid numeric input, but does not handle EOF, keyboard interruption or every Unicode numeric character.

## Git evidence

```bash
git log --oneline --graph
git log --format=fuller --stat
```

The correct option is `--oneline`. The assignment's `--online` spelling is a typo.

**History scope:** this repository starts by importing an already-written program. Subsequent commits record documentation and verification performed after that import. These commits do not establish when the original features were designed or implemented. See [Git history](docs/git-history.md).

## Language note

The supplied source file states that the lecturer allowed Python for this group. The assignment brief specifies C++; the repository preserves the supplied Python version and does not independently verify that permission.
